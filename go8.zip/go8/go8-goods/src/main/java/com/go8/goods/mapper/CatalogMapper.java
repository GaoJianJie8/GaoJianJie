package com.go8.goods.mapper;

import java.util.List;
import com.go8.goods.pojo.Catalog;

public interface CatalogMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Catalog record);

    int insertSelective(Catalog record);

    Catalog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Catalog record);

    int updateByPrimaryKey(Catalog record);
    
    List<Catalog> selectSonsByPid(Long pid);

	String selectCodeByCode(String code);
}