package com.go8.goods.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.go8.goods.mapper.CatalogMapper;
import com.go8.goods.pojo.Catalog;
/**
 * catalog logic
 * @author cjl
 */
@Service
public class CatalogServiceImpl implements CatalogService {
	@Autowired
	private CatalogMapper catalogMapper;

	@Override
	public void add(Catalog catalog) {
		// 添加逻辑：1，如果本来是父类目，直接添加子类；2，如果本来是子类目，先修改为父类目，再添加子类目
		Catalog parent = catalogMapper.selectByPrimaryKey(catalog.getPid());
		if (parent != null && !parent.getParent()) {
			parent.setGmtModified(new Date());
			parent.setParent(true);
			catalogMapper.updateByPrimaryKeySelective(parent);
		}
		Date now = new Date();
		catalog.setGmtCreate(now);
		catalog.setGmtModified(now);
		catalogMapper.insert(catalog);
	}

	@Override
	public Catalog getCatalogById(Long id) {
		// 查询单体
		return catalogMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Catalog> getSonsByPid(Long pid) {
		// 查询子类目
		return catalogMapper.selectSonsByPid(pid);
	}
	
	@Override
	public String getCode(String code) {
		// 查询指定code是否存在
		return catalogMapper.selectCodeByCode(code);
	}

	@Override
	public void update(Catalog catalog) {
		// 修改：禁止直接修改类目类型，就是修改是否是父类目，这个不是业务字段
		catalog.setGmtModified(new Date());
		catalogMapper.updateByPrimaryKeySelective(catalog);
	}

	@Override
	public void delete(Long id) {
		// 删除：1，如果是叶子，直接删除；2，如果是父亲，先删除后代，再删除自己
		Catalog catalog = catalogMapper.selectByPrimaryKey(id);
		if (catalog != null && catalog.getParent()) {
			deleteSonsByPid(id);
		}
		catalogMapper.deleteByPrimaryKey(id);
		// 最后都要判断其父类目下是否有子类目，如果没有则修改为叶子
		if (catalog != null) {
			Long pid = catalog.getPid();
			List<Catalog> list = catalogMapper.selectSonsByPid(pid);
			if (list == null || list.size() == 0) {
				Catalog parent = new Catalog();
				parent.setId(pid);
				parent.setParent(false);
				parent.setGmtModified(new Date());
				catalogMapper.updateByPrimaryKeySelective(parent);
			}
		}
	}

	// 递归删除某个父类目下的所有后代类目
	private void deleteSonsByPid(Long pid) {
		List<Catalog> sons = catalogMapper.selectSonsByPid(pid);
		if (sons != null) {
			for (Catalog cat : sons) {
				// 判断是否是叶子
				if (cat.getParent()) {
					deleteSonsByPid(cat.getId());
					catalogMapper.deleteByPrimaryKey(cat.getId());
				} else {
					catalogMapper.deleteByPrimaryKey(cat.getId());
				}
			}
		}
	}

	/**
	 * 获取所有的子孙类别：all
	 */
	@Override
	public List<Catalog> getAllChildrenByPid(Long pid) {
		//先获取第一节
		List<Catalog> list = catalogMapper.selectSonsByPid(pid);
		for(Catalog cat : list) {
			//如果是父节点继续查子节点
			if(cat.getParent()) {
				List<Catalog> sons = getAllChildrenByPid(cat.getId());
				cat.setChildren(sons);
			}
		}
		return list;
	}
}
