package com.go8.goods.service;

import java.util.List;
import com.go8.goods.pojo.Catalog;

public interface CatalogService {
	void add(Catalog catalog);
	
	void update(Catalog catalog);
	
	void delete(Long id);
	
	String getCode(String code);
	
	Catalog getCatalogById(Long id);
	
	List<Catalog> getSonsByPid(Long pid);
	
	List<Catalog> getAllChildrenByPid(Long pid);
}
