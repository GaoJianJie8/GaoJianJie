package com.go8.util;

import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

public class UtilTest {

	@Test
	public void testStringUtils() {
		int index = StringUtils.indexOf("http://192.168.19.131/group1/M00/00/00/wKgTg1w2w66AZlqCAAJRZnDMCEk197.jpg",
				"/group");
		System.out.println(index);
		
		String url = StringUtils.substring("http://192.168.19.131/group1/M00/00/00/wKgTg1w2w66AZlqCAAJRZnDMCEk197.jpg", 
				index+1);
		System.out.println(url);
		
		String uu = RegExUtils.removePattern("http://192.168.19.131/group1/M00/00/00/wKgTg1w2w66AZlqCAAJRZnDMCEk197.jpg", 
				"/group[1-9]");
		System.out.println(uu);
		
	}

}
