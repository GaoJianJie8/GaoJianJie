package com.go8.goods.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.github.tobato.fastdfs.domain.fdfs.StorePath;
import com.github.tobato.fastdfs.service.FastFileStorageClient;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class FdfsClientTest {
	@Autowired
	FastFileStorageClient client;

	@Test
	public void testUpload() throws Exception {
		File file = new File("D:\\cjl\\images\\img11.jpg");
		
		InputStream inputStream = new FileInputStream(file);

		StorePath path = client.uploadFile(inputStream, file.length(), "jpg", null);
		
		System.out.println(path.getPath());
		System.out.println(path.getGroup());
	}
	
	@Test
	public void testDelete() throws Exception {
		client.deleteFile("group1/M00/00/00/wKgTglwnSxCALpV1AAEvyIV-X1c196.jpg");
	}

}
