package com.go8.goods.mapper;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.go8.common.MysqlPageWrapper;
import com.go8.goods.pojo.Brand;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class BrandMapperTest {
	@Autowired
	private BrandMapper brandMapper;

	@Test
	public void testAdd() {
		for (int i = 1; i <= 10; i++) {
			Brand b = new Brand();
			b.setCatName("catname01"+i);
			b.setCid(1L+i);
			b.setCname("雀巢" + i);
			b.setEname("quechao" + i);
			b.setGmtCreate(new Date());
			b.setGmtModified(new Date());
			brandMapper.insert(b);
		}
	}

	@Test
	public void testSelectByCondition() {
		MysqlPageWrapper<Brand> condition = new MysqlPageWrapper<Brand>(1,10);
		Brand b = new Brand();
		b.setCatName("catname");
		b.setCname("雀巢");
		condition.setT(b);
		List<Brand> brands = brandMapper.selectByCondition(condition );
		assertEquals(0, brands.size());
	}
	
	@Test
	public void testSelectCountByCondition() {
		Brand b = new Brand();
		b.setCatName("catname");
		b.setCname("雀巢");
		long count = brandMapper.selectCountByCondition(b);
		assertEquals(0, count);
	}
}
