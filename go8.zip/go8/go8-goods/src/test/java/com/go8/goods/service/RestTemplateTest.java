package com.go8.goods.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.go8.common.service.help.ServiceResponseDeserializer;
import com.go8.goods.pojo.Brand;
import com.go8.goods.pojo.IndexProduct;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class RestTemplateTest {
	@Autowired
	private RestTemplate restTemplate;

	@Test
	public void testPost() {
		ParameterizedTypeReference<ServiceResponseDeserializer> typeRef = new ParameterizedTypeReference<ServiceResponseDeserializer>() {};
		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_UTF8_VALUE);
		/*header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);*/
		header.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		MultiValueMap<String, String> params= new LinkedMultiValueMap<String, String>();
		//  也支持中文
		params.add("id", "13330");
		params.add("title", "警方立即分解");
		params.add("price", "1236654");
		
		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<MultiValueMap<String, String>>(params, header);
		ResponseEntity<ServiceResponseDeserializer> srResponse = restTemplate
				.exchange("http://GO8-SERVICE-SEARCH/search/api", HttpMethod.POST, requestEntity,typeRef);
		ServiceResponseDeserializer sr = srResponse.getBody();
		System.out.println(sr.getStatus().getCode());
	}

}
