package com.go8.goods.service;

import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.go8.goods.pojo.Catalog;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CatalogServiceTest {
	@Autowired private CatalogService catalogService;
	@Test
	public void testGetAllChildrenByPid() {
		List<Catalog> all = catalogService.getAllChildrenByPid(0L);
		System.out.println(all);
	}

}
