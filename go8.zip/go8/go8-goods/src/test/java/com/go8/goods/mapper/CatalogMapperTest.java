package com.go8.goods.mapper;

import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.go8.goods.pojo.Catalog;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CatalogMapperTest {
	@Autowired
	private CatalogMapper catalogMapper;
	
	@Test
	public void testInsert() {
		Catalog cat = new Catalog();
		cat.setCode("yifu");
		cat.setName("衣服");
		cat.setOrder1(1);
		cat.setParent(true);
		cat.setPid(0L);
		Date now = new Date();
		cat.setGmtCreate(now);
		cat.setGmtModified(now);
		int insert = catalogMapper.insert(cat);
		assertEquals(1, insert);
	}

}
