package com.go8.goods.mapper;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.go8.goods.pojo.Attribute;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class AttributeMapperTest {
	@Autowired
	private AttributeMapper attributeMapper;

	@Test
	public void testSelectAttributeAndValue() {
		Attribute attr = new Attribute();
		attr.setCid(1L);
		attr.setType((byte) 1);
		attributeMapper.selectAttributeAndValue(attr);
	}

}
